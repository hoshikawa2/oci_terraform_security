#!/bin/bash
./curl-oci.sh resourcemanager.us-ashburn-1.oraclecloud.com POST ./request.json "/20180917/jobs"
